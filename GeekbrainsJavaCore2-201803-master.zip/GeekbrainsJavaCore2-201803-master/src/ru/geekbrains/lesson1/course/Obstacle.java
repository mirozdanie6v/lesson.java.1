package ru.geekbrains.lesson1.course;

import ru.geekbrains.lesson1.Participant;

/**
 * Класс абстрактное препятствие
 */
public abstract class Obstacle {

    public abstract void doIt(Participant participant);
}
